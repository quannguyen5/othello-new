package com.anhnd.matchservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MatchserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(MatchserviceApplication.class, args);
	}

}
