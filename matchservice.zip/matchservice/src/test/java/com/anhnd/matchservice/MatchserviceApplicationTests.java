package com.anhnd.matchservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MatchserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
